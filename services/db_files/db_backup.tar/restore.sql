--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16rc1
-- Dumped by pg_dump version 16.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE final_sprint_db;
--
-- Name: final_sprint_db; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE final_sprint_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_Canada.1252';


ALTER DATABASE final_sprint_db OWNER TO postgres;

\connect final_sprint_db

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Logins; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Logins" (
    id integer NOT NULL,
    username character varying NOT NULL,
    password character varying NOT NULL
);


ALTER TABLE public."Logins" OWNER TO postgres;

--
-- Name: Logins_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Logins_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Logins_id_seq" OWNER TO postgres;

--
-- Name: Logins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Logins_id_seq" OWNED BY public."Logins".id;


--
-- Name: procedures; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.procedures (
    id integer NOT NULL,
    name character varying NOT NULL,
    billing_number character varying NOT NULL
);


ALTER TABLE public.procedures OWNER TO postgres;

--
-- Name: procedures_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.procedures_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.procedures_id_seq OWNER TO postgres;

--
-- Name: procedures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.procedures_id_seq OWNED BY public.procedures.id;


--
-- Name: user_search; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_search (
    id uuid NOT NULL,
    username character varying NOT NULL,
    keywords character varying NOT NULL,
    "timestamp" character varying NOT NULL
);


ALTER TABLE public.user_search OWNER TO postgres;

--
-- Name: Logins id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Logins" ALTER COLUMN id SET DEFAULT nextval('public."Logins_id_seq"'::regclass);


--
-- Name: procedures id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procedures ALTER COLUMN id SET DEFAULT nextval('public.procedures_id_seq'::regclass);


--
-- Data for Name: Logins; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Logins" (id, username, password) FROM stdin;
\.
COPY public."Logins" (id, username, password) FROM '$$PATH$$/4800.dat';

--
-- Data for Name: procedures; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.procedures (id, name, billing_number) FROM stdin;
\.
COPY public.procedures (id, name, billing_number) FROM '$$PATH$$/4798.dat';

--
-- Data for Name: user_search; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_search (id, username, keywords, "timestamp") FROM stdin;
\.
COPY public.user_search (id, username, keywords, "timestamp") FROM '$$PATH$$/4801.dat';

--
-- Name: Logins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Logins_id_seq"', 1, false);


--
-- Name: procedures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.procedures_id_seq', 1, false);


--
-- Name: Logins Logins_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Logins"
    ADD CONSTRAINT "Logins_pkey" PRIMARY KEY (id);


--
-- Name: procedures procedures_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procedures
    ADD CONSTRAINT procedures_pkey PRIMARY KEY (id);


--
-- Name: Logins uq_username; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Logins"
    ADD CONSTRAINT uq_username UNIQUE (username);


--
-- Name: user_search user_search_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_search
    ADD CONSTRAINT user_search_pkey PRIMARY KEY (id);


--
-- Name: user_search username; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_search
    ADD CONSTRAINT username FOREIGN KEY (username) REFERENCES public."Logins"(username);


--
-- PostgreSQL database dump complete
--

